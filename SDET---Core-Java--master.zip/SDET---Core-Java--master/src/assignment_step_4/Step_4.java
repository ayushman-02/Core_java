package assignment_step_4;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Scanner;

import assignment_step_4_query.DataTypeDefinitions;
import assignment_step_4_query.Header;
import assignment_step_4_reader.CsvQueryProcessor;


public class Step_4 {
	
	public static void main(String[] args){
		
		
		//read the file name from the user
		
		
		/*
		 * create object of CsvQueryProcessor. We are trying to read from a file inside
		 * the constructor of this class. Hence, we will have to handle exceptions.
		 */
					
		
		//call getHeader() method to get the array of headers
		
		
		/*
		 * call getColumnType() method of CsvQueryProcessor class to retrieve the array
		 * of column data types which is actually the object of DataTypeDefinitions
		 * class
		 */
				
		
		/*
		 * display the columnName from the header object along with its data type from
		 * DataTypeDefinitions object
		 */
		
		
		
	}

}
