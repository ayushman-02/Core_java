package assignment_step_4_query;

//this class contains the data type definitions
public class DataTypeDefinitions {

	/*
	 * this class should contain a member variable which is a String array, to hold
	 * the data type for all columns for all data types
	 */	
	public String[] getDataTypes() {
		return null;
	}
}
