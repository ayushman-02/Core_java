package assignment_3_query;

//header class
public class Header {

	/*
	 * this class should contain a member variable which is a String array, to hold
	 * the headers.
	 */
	

	public String[] getHeaders() {
		return null;
	}

}
